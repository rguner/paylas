// Capthca BEGIN
var captchaId;

function refreshCaptcha() {
	$.ajax({
		url: '/site/captcha?' + new Date().getTime(),
		headers: { 'X-Tcell-Ajax': 'true' }
	}).done(function(response) {
		captchaId = response;
		var url = captchaUrl + ".jpg?id=" + captchaId;
		$('.captcha .img img').attr('src', url);
		$('[name=captcha]', $('.captcha').parents('form')).val('');
	});
	$('audio, embed', '.captcha .captchaVoice').remove();
}

function playCaptcha(cont) {
	$('audio, embed', '.captcha .captchaVoice').remove();
	setTimeout(function() {
		var url = captchaUrl + '.wav?id=' + captchaId;
		if(checkPlayable()) {
			$('.captchaVoice', cont.parents('table.captcha')).append("<audio src='" + url + "' hidden='true' autoplay='autoplay'/>");
		} else {
			$('.captchaVoice', cont.parents('table.captcha')).append("<embed src='" + url + "' hidden='true' autostart='true' loop='false'/>");
		}
	}, 250);
}

function checkPlayable() {
	var a = document.createElement('audio');
	return !!(a.canPlayType && a.canPlayType('audio/wav;').replace(/no/, ''));
}

function captchaControls(cont){
	if(!cont) {
		cont = $('body');
	}
	$('[name=captcha]', cont).on("textchange", function(e) {
        // lower all
        var input = $(this);
        input.val(input.val().toLowerCaseTR());
    });
	$('.captcha .control.refresh', cont).click(function() {
		refreshCaptcha();
	});
	$('.captcha .control.speaker', cont).click(function() {
		playCaptcha($(this));
	});
}

$(function() {
	captchaControls();
});
// Capthca END
